import torch
import os
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader, random_split
from dataset import BrainDataset
from model import UNet
import numpy as np
import cv2

def dice_score(pred, target):
    pred = pred.flatten()
    target = target.flatten()
    intersection = (pred * target).sum()
    return (2. * intersection) / (pred.sum() + target.sum() + 1e-8)

dataset = BrainDataset()

train_size = int(0.8 * len(dataset))
test_size = len(dataset) - train_size

_, test_dataset = random_split(dataset, [train_size, test_size])
test_loader = DataLoader(test_dataset, batch_size=1)

model = UNet()
model.load_state_dict(torch.load("outputs/models/unet.pth"))
model.eval()

os.makedirs("outputs/results", exist_ok=True)

dice_scores = []

with torch.no_grad():
    for i, (img, mask) in enumerate(test_loader):

        img = img.float()
        pred = model(img)

        pred_img = (pred[0][0].numpy() > 0.5).astype("float32")

        # remove noise
        pred_img = (pred_img * 255).astype("uint8")
        pred_img = cv2.medianBlur(pred_img, 5)
        pred_img = pred_img / 255.0

        gt = mask[0][0].numpy()

        dice = dice_score(pred_img, gt)
        dice_scores.append(dice)

        plt.figure(figsize=(10,3))

        plt.subplot(1,3,1)
        plt.imshow(img[0].permute(1,2,0))
        plt.title("Input")

        plt.subplot(1,3,2)
        plt.imshow(gt, cmap='gray')
        plt.title("Mask")

        plt.subplot(1,3,3)
        plt.imshow(pred_img, cmap='gray')
        plt.title("Prediction")

        plt.savefig(f"outputs/results/pred_{i}.png")
        plt.close()

        if i == 5:
            break

print("Average Dice Score:", np.mean(dice_scores))