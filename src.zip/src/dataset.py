import os
import cv2
import numpy as np
from torch.utils.data import Dataset

class BrainDataset(Dataset):
    def __init__(self):
        self.image_paths = []
        self.mask_paths = []

        # ===== 1. BRATS DATASET =====
        brats_img = r"Data/BraTs Dataset/glioma split data/train/images"
        brats_mask = r"Data/BraTs Dataset/glioma split data/train/masks"

        if os.path.exists(brats_img):
            for file in os.listdir(brats_img):
                img_path = os.path.join(brats_img, file)
                mask_path = os.path.join(brats_mask, file)

                if os.path.exists(mask_path):
                    mask = cv2.imread(mask_path, 0)

                    if mask is not None and np.sum(mask) > 0:
                        self.image_paths.append(img_path)
                        self.mask_paths.append(mask_path)

        # ===== 2. OTHER DATASET =====
        other_img = r"Data/Dataset/images"
        other_mask = r"Data/Dataset/masks"

        if os.path.exists(other_img):
            for file in os.listdir(other_img):
                img_path = os.path.join(other_img, file)
                mask_path = os.path.join(other_mask, file)

                if os.path.exists(mask_path):
                    mask = cv2.imread(mask_path, 0)

                    if mask is not None and np.sum(mask) > 0:
                        self.image_paths.append(img_path)
                        self.mask_paths.append(mask_path)

        # ===== 3. LGG DATASET (.tif inside folders) =====
        lgg_root = r"Data/lgg/lgg-mri-segmentation/kaggle_3m/"

        if os.path.exists(lgg_root):
            for sub1 in os.listdir(lgg_root):
                path1 = os.path.join(lgg_root, sub1)

                if not os.path.isdir(path1):
                    continue

                for sub2 in os.listdir(path1):
                    path2 = os.path.join(path1, sub2)

                    if not os.path.isdir(path2):
                        continue

                    for patient in os.listdir(path2):
                        patient_path = os.path.join(path2, patient)

                        if not os.path.isdir(patient_path):
                            continue

                        for file in os.listdir(patient_path):
                            if file.endswith(".tif") and "_mask" not in file:
                                img_path = os.path.join(patient_path, file)
                                mask_path = os.path.join(
                                    patient_path,
                                    file.replace(".tif", "_mask.tif")
                                )

                                if os.path.exists(mask_path):
                                    mask = cv2.imread(mask_path, 0)

                                    if mask is not None and np.sum(mask) > 0:
                                        self.image_paths.append(img_path)
                                        self.mask_paths.append(mask_path)

        print("✅ Total samples loaded:", len(self.image_paths))

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img = cv2.imread(self.image_paths[idx], cv2.IMREAD_UNCHANGED)
        img = cv2.resize(img, (128,128))

        # convert grayscale → 3 channel if needed
        if len(img.shape) == 2:
            img = np.stack([img]*3, axis=-1)

        mask = cv2.imread(self.mask_paths[idx], 0)
        mask = cv2.resize(mask, (128,128))

        # augmentation
        if np.random.rand() > 0.5:
            img = cv2.flip(img, 1)
            mask = cv2.flip(mask, 1)

        # normalize
        img = img / 255.0
        mask = (mask > 0).astype("float32")

        mask = np.expand_dims(mask, axis=0)

        return img.transpose(2,0,1), mask