import torch
import os
from torch.utils.data import DataLoader, random_split
from dataset import BrainDataset
from model import UNet
from utils import dice_loss
import torch.nn.functional as F

dataset = BrainDataset()

train_size = int(0.8 * len(dataset))
test_size = len(dataset) - train_size

train_dataset, _ = random_split(dataset, [train_size, test_size])

train_loader = DataLoader(train_dataset, batch_size=4, shuffle=True)

model = UNet()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

for epoch in range(25):
    for img, mask in train_loader:

        img = img.float()
        mask = mask.float()

        pred = model(img)

        loss = dice_loss(pred, mask) + 0.5 * F.binary_cross_entropy(pred, mask)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    print(f"Epoch {epoch} Loss: {loss.item()}")

os.makedirs("outputs/models", exist_ok=True)
torch.save(model.state_dict(), "outputs/models/unet.pth")

print("✅ Model saved!")